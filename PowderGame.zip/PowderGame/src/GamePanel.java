import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.Random;

public class GamePanel extends JPanel implements ActionListener {

    static final int SCREEN_WIDTH = 640;
    static final int SCREEN_HEIGHT = 420;
    static final int BOX_SIZE = 5;
    static final int GAME_UNITS = (SCREEN_WIDTH * SCREEN_HEIGHT) / BOX_SIZE;
    static final int DELAY = 50;
    static final int HORIZONTAL_UNITS = SCREEN_WIDTH / BOX_SIZE;
    static final int VERTICAL_UNITS = SCREEN_HEIGHT / BOX_SIZE;
    boolean running = false;
    Timer timer;
    Random random;
    int typeSelected = 0;
    int radius = 1;

    public static Cell[][] board = new Cell[SCREEN_WIDTH / BOX_SIZE][SCREEN_HEIGHT / BOX_SIZE];

    GamePanel() {
        random = new Random();
        this.setPreferredSize(new Dimension(SCREEN_WIDTH, SCREEN_HEIGHT));
        this.setBackground(Color.black);
        this.setFocusable(true);
        this.addKeyListener(new MyKeyAdapter());
        this.addMouseMotionListener(new MouseMotionListener() {
            @Override
            public void mouseDragged(MouseEvent e) {
                placeParticle(e.getX() / BOX_SIZE, e.getY() / BOX_SIZE);
            }

            @Override
            public void mouseMoved(MouseEvent e) {

            }
        });
        this.addMouseListener(new MouseListener() {
            @Override
            public void mouseClicked(MouseEvent e) {
            }

            @Override
            public void mousePressed(MouseEvent e) {
                placeParticle(e.getX() / BOX_SIZE, e.getY() / BOX_SIZE);
            }

            @Override
            public void mouseReleased(MouseEvent e) {
            }

            @Override
            public void mouseEntered(MouseEvent e) {
            }

            @Override
            public void mouseExited(MouseEvent e) {
            }
        });
        startGame();
    }

    public void startGame() {
        for (int i = 0; i < SCREEN_WIDTH / BOX_SIZE; i++) { //initializing array
            for (int j = 0; j < SCREEN_HEIGHT / BOX_SIZE; j++) {
                board[i][j] = new Cell(0, i, j);
            }
        }
        //testing
        //board[5][5].setType(1);

        running = true;
        timer = new Timer(DELAY, this);
        timer.start();
    }

    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        draw(g);
    }

    public void draw(Graphics g) {
        for (int i = 0; i < SCREEN_WIDTH / BOX_SIZE; i++) { //initializing array
            for (int j = 0; j < SCREEN_HEIGHT / BOX_SIZE; j++) {
                //drawing squares
                g.setColor(board[i][j].colour);
                g.fillRect(i * BOX_SIZE, j * BOX_SIZE, BOX_SIZE, BOX_SIZE);
            }
        }
        //UI elements
        g.setColor(Color.WHITE);
        g.setFont(new Font("VCR OSD Mono", Font.PLAIN, 20));
        FontMetrics metricsRadius = getFontMetrics(g.getFont());
        g.drawString("Radius: " + radius, SCREEN_WIDTH - metricsRadius.stringWidth("Radius: " + radius) - 10,
                20);

        g.setFont(new Font("VCR OSD Mono", Font.PLAIN, 13));
        g.drawString("Use Arrow Keys", SCREEN_WIDTH - metricsRadius.stringWidth("Radius: " + radius) - 10,
                35);

        g.drawString("1: Air 2: Sand 3: Water 4: Wood 5: Fire 6: Stone", 5, 15);

    }

    public void updateCells() {
        for (int i = 0; i < SCREEN_WIDTH / BOX_SIZE; i++) { //goes from bottom to top, updating each cell if it's not air for optimization
            for (int j = SCREEN_HEIGHT / BOX_SIZE - 1; j >= 0; j--) {
                if (board[i][j].type != 0) {
                    board[i][j].updateCell();
                    board[i][j].xPos = i;
                    board[i][j].yPos = j;
                }
            }
        }
    }

    public void placeParticle(int x, int y) {
        //System.out.println("Placed");
        for (int i = -radius; i <= radius; i++) { //places a 3x3 square of particles
            for (int j = -radius; j <= radius; j++) {
                //System.out.println(i + " " + j);
                if (board[x + i][y + j].type == 0 || typeSelected == 0) {
                    board[x + i][y + j].setType(typeSelected);
                }
            }
        }
    }

    public class MyKeyAdapter extends KeyAdapter {
        @Override
        public void keyPressed(KeyEvent e) {
            switch (e.getKeyCode()) {
                case KeyEvent.VK_1 -> typeSelected = 0; //air
                case KeyEvent.VK_2 -> typeSelected = 1; //sand
                case KeyEvent.VK_3 -> typeSelected = 2; //water
                case KeyEvent.VK_4 -> typeSelected = 3; //wood
                case KeyEvent.VK_5 -> typeSelected = 4; //fire
                case KeyEvent.VK_6 -> typeSelected = 6; //stone

            }
            switch (e.getKeyCode()) {
                case KeyEvent.VK_UP -> {
                    if (radius < 6) radius++;
                    System.out.println(radius);
                }
                case KeyEvent.VK_DOWN -> {
                    if (radius > 0) radius--;
                    System.out.println(radius);
                }
            }

        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (running) {
            updateCells();
            //System.out.println("Type: " + typeSelected);
        }
        repaint();
    }

}
