import java.awt.*;

public class Cell {
    int type;
    int xPos;
    int yPos;
    double density;
    int lifetime;
    Color colour;

    public Cell(int t, int x, int y) {
        type = t;
        xPos = x;
        yPos = y;
        assignAttributes();
    }

    public void setType(int t) {
        type = t;
        assignAttributes();
    }

    public void assignAttributes() {
        switch (type) {
//air
            case 0 -> {
                density = 0;
                colour = Color.BLACK;
                lifetime = 0;
            }
//sand
            case 1 -> {
                int randSa = (int) (Math.random() * 70) + 185;
                density = 1;
                colour = new Color(randSa, randSa, 0);
                lifetime = 0;
            }
//water
            case 2 -> {
                density = 0.5;
                colour = new Color(0, 0, (int) (Math.random() * 155) + 100);
                lifetime = 0;
            }
//wood
            case 3 -> {
                density = 10;
                colour = new Color(235, 147, 65);
                lifetime = 0;
            }
//fire
            case 4 -> {
                density = 10;
                colour = new Color(255, (int) (Math.random() * 255), 0);
                lifetime = (int) (Math.random() * 20) + 20;
            }
//smoke
            case 5 -> {
                int randS = (int) (Math.random() * 255);
                density = 0.1;
                colour = new Color(randS, randS, randS);
                lifetime = (int) (Math.random() * 100) + 50;
            }
//stone
            case 6 -> {
                density = 10;
                colour = new Color(200, 200, 200);
                lifetime = 0;
            }
        }
    }

    public void updateCell() {
        if (lifetime != 0) {
            lifetime--;
        }
        //logic for each element
        switch (type) {
            case 0: //air / nothing
                break;
            case 1: //sand logic
                if (availableCell("down")) { //down
                    flipCells(xPos, yPos + 1);
                } else if (availableCell("down left")) { //down and left
                    flipCells(xPos - 1, yPos + 1);
                } else if (availableCell("down right")) { //down and right
                    flipCells(xPos + 1, yPos + 1);
                }
                break;
            case 2: //water logic
                colour = new Color(0, 0, (int) (Math.random() * 155) + 100);
                int leftOrRightWater = (int) (Math.random() * 2);
                if (availableCell("down")) {
                    flipCells(xPos, yPos + 1); //down
                } else if (availableCell("down left")) {//down left
                    flipCells(xPos - 1, yPos + 1);
                } else if (availableCell("down right")) {
                    flipCells(xPos + 1, yPos + 1); //down right
                } else if (leftOrRightWater == 0 && availableCell("right")) { //right
                    if (Math.random() > 0.2) {
                        flipCells(xPos + 1, yPos);
                    }
                } else if (leftOrRightWater == 1 && availableCell("left")) { //left
                    if (Math.random() > 0.2) {
                        flipCells(xPos - 1, yPos);
                    }
                }
                if(availableCell("right") && !availableCell("left")){
                    if(Math.random() > 0.1){
                        flipCells(xPos + 1, yPos);
                    }
                }else if(availableCell("left") && !availableCell("right")){
                    if(Math.random() > 0.1){
                        flipCells(xPos - 1, yPos);
                    }
                }
                break;
            case 3: //wood logic
                break;
            case 4: //fire logic
                colour = new Color(255, (int) (Math.random() * 255), 0);
                if (lifetime == 1) {
                    setType(5);
                    break;
                }

                int randIgnite = (int) (Math.random() * 8);
                switch (randIgnite) {
                    case 0:
                        if (xPos != 0) {
                            if (GamePanel.board[xPos - 1][yPos].type == 3) {
                                GamePanel.board[xPos - 1][yPos].setType(4);
                            }
                        }
                        break;
                    case 1:
                        if (xPos != 0 && yPos != 0) {
                            if (GamePanel.board[xPos - 1][yPos - 1].type == 3) {
                                GamePanel.board[xPos - 1][yPos - 1].setType(4);
                            }
                        }
                        break;
                    case 2:
                        if (yPos != 0) {
                            if (GamePanel.board[xPos][yPos - 1].type == 3) {
                                GamePanel.board[xPos][yPos - 1].setType(4);
                            }
                        }
                        break;
                    case 3:
                        if (xPos != GamePanel.HORIZONTAL_UNITS - 1 && yPos != 0) {
                            if (GamePanel.board[xPos + 1][yPos - 1].type == 3) {
                                GamePanel.board[xPos + 1][yPos - 1].setType(4);
                            }
                        }
                        break;
                    case 4:
                        if (xPos != GamePanel.HORIZONTAL_UNITS - 1) {
                            if (GamePanel.board[xPos + 1][yPos].type == 3) {
                                GamePanel.board[xPos + 1][yPos].setType(4);
                            }
                        }
                        break;
                    case 5:
                        if (xPos != GamePanel.HORIZONTAL_UNITS - 1 && yPos != GamePanel.VERTICAL_UNITS - 1) {
                            if (GamePanel.board[xPos + 1][yPos].type == 3) {
                                GamePanel.board[xPos + 1][yPos].setType(4);
                            }
                        }
                        break;
                    case 6:
                        if (yPos != GamePanel.VERTICAL_UNITS - 1) {
                            if (GamePanel.board[xPos][yPos + 1].type == 3) {
                                GamePanel.board[xPos][yPos + 1].setType(4);
                            }
                        }
                        break;
                    case 7:
                        if (xPos != 0 && yPos != GamePanel.VERTICAL_UNITS - 1) {
                            if (GamePanel.board[xPos - 1][yPos + 1].type == 3) {
                                GamePanel.board[xPos - 1][yPos + 1].setType(4);
                            }
                        }
                        break;
                }
                break;
            case 5: //smoke logic
                if (lifetime == 1) {
                    setType(0);
                    break;
                }
                int leftOrRightSmoke = (int) (Math.random() * 2);
                double rand = Math.random();
                if (rand < 0.2 && availableCell("up left")) {
                    flipCells(xPos - 1, yPos - 1);
                } else if (rand < 0.8 && availableCell("up")) {
                    flipCells(xPos, yPos - 1);
                } else if (availableCell("up right")) {
                    flipCells(xPos + 1, yPos - 1);
                } else if (leftOrRightSmoke == 0 && availableCell("right")) { //right
                    if (Math.random() > 0.2) {
                        flipCells(xPos + 1, yPos);
                    }
                } else if (leftOrRightSmoke == 1 && availableCell("left")) { //left
                    if (Math.random() > 0.2) {
                        flipCells(xPos - 1, yPos);
                    }
                }
                break;
            case 6: //stone logic
                break;
        }
    }

    public void flipCells(int xToFlip, int yToFlip) {
        Cell temp = GamePanel.board[xPos][yPos];
        GamePanel.board[xPos][yPos] = GamePanel.board[xToFlip][yToFlip];
        GamePanel.board[xToFlip][yToFlip] = temp;
    }

    public boolean availableCell(String pos) {
        boolean isAvailable = false; //checks provided cell position relatively, false if occupied
        switch (pos) {
            case "down":
                if (yPos == GamePanel.VERTICAL_UNITS - 1) { //at bottom
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos][yPos + 1].density < this.density;
                break;
            case "down left":
                if (yPos == GamePanel.VERTICAL_UNITS - 1 //at bottom
                        || xPos == 0) { //at left edge
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos - 1][yPos + 1].density < this.density;
                break;
            case "down right":
                if (yPos == GamePanel.VERTICAL_UNITS - 1 //at bottom
                        || xPos == GamePanel.HORIZONTAL_UNITS - 1) { //at right edge
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos + 1][yPos + 1].density < this.density;
                break;
            case "left":
                if (xPos == 0) { //at left edge
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos - 1][yPos].density < this.density;
                break;
            case "right":
                if (xPos == GamePanel.HORIZONTAL_UNITS - 1) { //at right edge
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos + 1][yPos].density < this.density;
                break;
            case "up":
                if (yPos == 0) { //at top
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos][yPos - 1].density < this.density;
                break;
            case "up left":
                if (yPos == 0 || xPos == 0) { //at top
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos - 1][yPos - 1].density < this.density;
                break;
            case "up right":
                if (yPos == 0 || xPos == GamePanel.HORIZONTAL_UNITS - 1) { //at top
                    isAvailable = false;
                } else isAvailable = GamePanel.board[xPos + 1][yPos - 1].density < this.density;
                break;
        }
        return isAvailable;
    }

}
