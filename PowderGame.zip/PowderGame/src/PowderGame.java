public class PowderGame {

    /*
    For Comp Sci ICS4UA-02
    Mr. Berardi
    Created by Tyler Steptoe
    This program simulates different elements in a grid-like system, interacting
    with each other in different ways. Select the element with 1-6 and place them
    by clicking the mouse. Use arrow keys to change size of brush.
     */
    public static void main(String[] args) {

        new GameFrame();

    }

}
